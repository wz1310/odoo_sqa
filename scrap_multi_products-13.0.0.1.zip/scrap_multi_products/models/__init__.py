# -*- coding: utf-8 -*-
from . import scrap_product
